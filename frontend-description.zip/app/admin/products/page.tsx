"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import type { Product } from "@/types/product"
import Link from "next/link"
import Image from "next/image"
import { useState, useEffect } from "react"
import { Trash2, Edit2, Plus } from "lucide-react"

// Mock data
const MOCK_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Wireless Headphones",
    description: "High-quality sound with noise cancellation",
    price: 79.99,
    category: "Electronics",
    image: "/wireless-headphones.png",
  },
  {
    id: "2",
    name: "Mechanical Keyboard",
    description: "RGB mechanical keyboard with premium switches",
    price: 129.99,
    category: "Peripherals",
    image: "/mechanical-keyboard.png",
  },
]

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setProducts(MOCK_PRODUCTS)
    setMounted(true)
  }, [])

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(products.filter((p) => p.id !== id))
    }
  }

  if (!mounted) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-3xl font-bold text-foreground">Products</h1>
            <Link
              href="/admin/products/create"
              className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            >
              <Plus size={20} />
              Create New
            </Link>
          </div>

          {/* Table */}
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-background border-b border-border">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Name</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Description</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Price</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Category</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Image</th>
                    <th className="px-6 py-3 text-center text-sm font-semibold text-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product) => (
                    <tr key={product.id} className="border-b border-border hover:bg-background transition-colors">
                      <td className="px-6 py-4 font-semibold text-foreground">{product.name}</td>
                      <td className="px-6 py-4 text-foreground text-sm">{product.description}</td>
                      <td className="px-6 py-4 text-foreground font-semibold">${product.price.toFixed(2)}</td>
                      <td className="px-6 py-4">
                        <span className="bg-blue-100 text-primary px-3 py-1 rounded-full text-sm font-semibold">
                          {product.category}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {product.image && (
                          <div className="relative w-10 h-10">
                            <Image
                              src={product.image || "/placeholder.svg"}
                              alt={product.name}
                              fill
                              className="object-cover rounded"
                            />
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Link
                            href={`/admin/products/${product.id}/edit`}
                            className="text-yellow-600 hover:text-yellow-700 transition-colors"
                            aria-label="Edit product"
                          >
                            <Edit2 size={18} />
                          </Link>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="text-destructive hover:text-destructive/80 transition-colors"
                            aria-label="Delete product"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
