"use client"

import type React from "react"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import Link from "next/link"
import { useState } from "react"
import { ArrowLeft, Check } from "lucide-react"

export default function CreateProductPage() {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
  })
  const [successMessage, setSuccessMessage] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSuccessMessage("Product created successfully!")
    setTimeout(() => {
      setFormData({ name: "", description: "", price: "", category: "", imageUrl: "" })
      setSuccessMessage("")
    }, 2000)
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          {/* Back Button */}
          <Link href="/admin/products" className="flex items-center gap-2 text-primary hover:underline mb-8">
            <ArrowLeft size={20} />
            Back to Products
          </Link>

          {/* Header */}
          <h1 className="text-3xl font-bold text-foreground mb-8">Add New Product</h1>

          {/* Success Message */}
          {successMessage && (
            <div className="mb-6 bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-3">
              <Check size={20} />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="bg-card border border-border rounded-lg shadow-sm p-6 space-y-6">
            <div>
              <label htmlFor="name" className="block font-semibold text-foreground mb-2">
                Product Name *
              </label>
              <input
                id="name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
                placeholder="Enter product name"
              />
            </div>

            <div>
              <label htmlFor="description" className="block font-semibold text-foreground mb-2">
                Description *
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={4}
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
                placeholder="Enter product description"
              />
            </div>

            <div>
              <label htmlFor="price" className="block font-semibold text-foreground mb-2">
                Price (USD) *
              </label>
              <input
                id="price"
                type="number"
                name="price"
                value={formData.price}
                onChange={handleChange}
                required
                step="0.01"
                min="0"
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
                placeholder="0.00"
              />
            </div>

            <div>
              <label htmlFor="category" className="block font-semibold text-foreground mb-2">
                Category *
              </label>
              <input
                id="category"
                type="text"
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
                placeholder="e.g., Electronics"
              />
            </div>

            <div>
              <label htmlFor="imageUrl" className="block font-semibold text-foreground mb-2">
                Image URL (optional)
              </label>
              <input
                id="imageUrl"
                type="url"
                name="imageUrl"
                value={formData.imageUrl}
                onChange={handleChange}
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
                placeholder="https://example.com/image.jpg"
              />
            </div>

            <div className="flex gap-4 pt-4">
              <button
                type="submit"
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-lg font-bold transition-colors"
              >
                Add Product
              </button>
              <Link
                href="/admin/products"
                className="flex-1 border border-border text-foreground hover:bg-background py-3 rounded-lg font-bold transition-colors text-center"
              >
                Cancel
              </Link>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </>
  )
}
