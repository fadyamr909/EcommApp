"use client"

import type React from "react"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import Link from "next/link"
import { useState, useEffect } from "react"
import { ArrowLeft, Check } from "lucide-react"

// Mock data for products
const MOCK_PRODUCTS: Record<string, any> = {
  "1": {
    id: "1",
    name: "Wireless Headphones",
    description: "High-quality sound with active noise cancellation. 30-hour battery life.",
    price: "79.99",
    category: "Electronics",
    image: "/wireless-headphones.png",
  },
}

interface EditProductProps {
  params: Promise<{ id: string }>
}

export default function EditProductPage({ params }: EditProductProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
  })
  const [successMessage, setSuccessMessage] = useState("")
  const [id, setId] = useState("")

  useEffect(() => {
    params.then((p) => {
      setId(p.id)
      const product = MOCK_PRODUCTS[p.id]
      if (product) {
        setFormData({
          name: product.name,
          description: product.description,
          price: product.price,
          category: product.category,
          imageUrl: product.image || "",
        })
      }
    })
  }, [params])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSuccessMessage("Product updated successfully!")
    setTimeout(() => setSuccessMessage(""), 2000)
  }

  if (!id) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          <Link href="/admin/products" className="flex items-center gap-2 text-primary hover:underline mb-8">
            <ArrowLeft size={20} />
            Back to Products
          </Link>

          <h1 className="text-3xl font-bold text-foreground mb-8">Edit Product</h1>

          {successMessage && (
            <div className="mb-6 bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-3">
              <Check size={20} />
              <span>{successMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="bg-card border border-border rounded-lg shadow-sm p-6 space-y-6">
            <div>
              <label htmlFor="name" className="block font-semibold text-foreground mb-2">
                Product Name *
              </label>
              <input
                id="name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
              />
            </div>

            <div>
              <label htmlFor="description" className="block font-semibold text-foreground mb-2">
                Description *
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={4}
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
              />
            </div>

            <div>
              <label htmlFor="price" className="block font-semibold text-foreground mb-2">
                Price (USD) *
              </label>
              <input
                id="price"
                type="number"
                name="price"
                value={formData.price}
                onChange={handleChange}
                required
                step="0.01"
                min="0"
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
              />
            </div>

            <div>
              <label htmlFor="category" className="block font-semibold text-foreground mb-2">
                Category *
              </label>
              <input
                id="category"
                type="text"
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
              />
            </div>

            <div>
              <label htmlFor="imageUrl" className="block font-semibold text-foreground mb-2">
                Image URL (optional)
              </label>
              <input
                id="imageUrl"
                type="url"
                name="imageUrl"
                value={formData.imageUrl}
                onChange={handleChange}
                className="w-full border border-border rounded-lg px-4 py-2 text-foreground"
              />
            </div>

            <div className="flex gap-4 pt-4">
              <button
                type="submit"
                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-3 rounded-lg font-bold transition-colors"
              >
                Save Changes
              </button>
              <Link
                href="/admin/products"
                className="flex-1 border border-border text-foreground hover:bg-background py-3 rounded-lg font-bold transition-colors text-center"
              >
                Cancel
              </Link>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </>
  )
}
