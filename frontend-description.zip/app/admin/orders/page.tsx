"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import type { Order } from "@/types/order"
import Link from "next/link"
import { useState, useEffect } from "react"
import { Eye } from "lucide-react"

// Mock data
const MOCK_ORDERS: Order[] = [
  {
    id: "#ORD-001",
    date: "Nov 28, 2025 10:30:00",
    items: [
      { id: "1", name: "Wireless Headphones", price: 79.99, quantity: 1 },
      { id: "3", name: "USB-C Cable", price: 14.99, quantity: 2 },
    ],
    subtotal: 109.97,
    tax: 10.997,
    total: 120.967,
  },
  {
    id: "#ORD-002",
    date: "Nov 27, 2025 14:15:00",
    items: [{ id: "2", name: "Mechanical Keyboard", price: 129.99, quantity: 1 }],
    subtotal: 129.99,
    tax: 12.999,
    total: 142.989,
  },
]

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setOrders(MOCK_ORDERS)
    setMounted(true)
  }, [])

  const totalOrdersValue = orders.reduce((sum, order) => sum + order.total, 0)

  if (!mounted) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-4xl font-bold text-foreground">All Orders</h1>
            {orders.length > 0 && (
              <span className="bg-primary text-primary-foreground px-4 py-2 rounded-full font-semibold">
                {orders.length} orders
              </span>
            )}
          </div>

          {/* Empty State */}
          {orders.length === 0 ? (
            <div className="text-center py-12 bg-background rounded-lg">
              <div className="text-6xl mb-4">📭</div>
              <p className="text-lg text-muted-foreground">No orders yet</p>
            </div>
          ) : (
            <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-background border-b border-border">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Order ID</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Date & Time</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Items</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Total Amount</th>
                      <th className="px-6 py-3 text-center text-sm font-semibold text-foreground">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order) => (
                      <tr key={order.id} className="border-b border-border hover:bg-background transition-colors">
                        <td className="px-6 py-4 text-primary font-bold">{order.id}</td>
                        <td className="px-6 py-4 text-foreground text-sm">{order.date}</td>
                        <td className="px-6 py-4">
                          <span className="bg-blue-100 text-primary px-3 py-1 rounded-full text-sm font-semibold">
                            {order.items.length} items
                          </span>
                        </td>
                        <td className="px-6 py-4 text-lg font-bold text-emerald-600">${order.total.toFixed(2)}</td>
                        <td className="px-6 py-4 text-center">
                          <Link
                            href={`/admin/orders/${encodeURIComponent(order.id)}`}
                            className="text-primary hover:text-primary/80 transition-colors"
                            aria-label="View order details"
                          >
                            <Eye size={18} />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-background border-t-2 border-border">
                    <tr>
                      <td colSpan={3} className="px-6 py-4 font-bold text-foreground">
                        Total Orders Value:
                      </td>
                      <td className="px-6 py-4 text-lg font-bold text-primary">${totalOrdersValue.toFixed(2)}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}
