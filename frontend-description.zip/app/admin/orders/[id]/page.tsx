"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import type { Order } from "@/types/order"
import Link from "next/link"
import { useState, useEffect } from "react"
import { ArrowLeft, ReceiptText } from "lucide-react"

// Mock data
const MOCK_ORDERS: Record<string, Order> = {
  "#ORD-001": {
    id: "#ORD-001",
    date: "Nov 28, 2025 10:30:00",
    items: [
      { id: "1", name: "Wireless Headphones", price: 79.99, quantity: 1 },
      { id: "3", name: "USB-C Cable", price: 14.99, quantity: 2 },
    ],
    subtotal: 109.97,
    tax: 10.997,
    total: 120.967,
  },
}

interface OrderDetailsProps {
  params: Promise<{ id: string }>
}

export default function OrderDetailsPage({ params }: OrderDetailsProps) {
  const [order, setOrder] = useState<Order | null>(null)
  const [id, setId] = useState("")

  useEffect(() => {
    params.then((p) => {
      setId(decodeURIComponent(p.id))
      const foundOrder = MOCK_ORDERS[decodeURIComponent(p.id)]
      setOrder(foundOrder || null)
    })
  }, [params])

  if (!id) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  if (!order) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <Link href="/admin/orders" className="flex items-center gap-2 text-primary hover:underline mb-8">
              <ArrowLeft size={20} />
              Back to Orders
            </Link>
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">Order not found</p>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          <Link href="/admin/orders" className="flex items-center gap-2 text-primary hover:underline mb-8">
            <ArrowLeft size={20} />
            Back to Orders
          </Link>

          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="bg-primary text-primary-foreground px-6 py-6 flex items-center gap-3">
              <ReceiptText size={24} />
              <div>
                <p className="text-sm opacity-90">Order</p>
                <h1 className="text-2xl font-bold">{order.id}</h1>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Order Date</p>
                <p className="text-lg font-semibold text-foreground">{order.date}</p>
              </div>

              <div>
                <h2 className="font-bold text-foreground mb-3">Order Items</h2>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-background border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Product</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Price</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Quantity</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody>
                      {order.items.map((item) => (
                        <tr key={item.id} className="border-b border-border">
                          <td className="px-4 py-3 text-foreground">{item.name}</td>
                          <td className="px-4 py-3 text-foreground">${item.price.toFixed(2)}</td>
                          <td className="px-4 py-3 text-foreground">{item.quantity}</td>
                          <td className="px-4 py-3 font-bold text-foreground">
                            ${(item.price * item.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="border-t border-border pt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-semibold text-foreground">${order.subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Tax (10%):</span>
                  <span className="font-semibold text-foreground">${order.tax.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center pt-3 border-t border-border">
                  <span className="font-bold text-lg text-foreground">Total:</span>
                  <span className="text-2xl font-bold text-primary">${order.total.toFixed(2)}</span>
                </div>
              </div>

              <Link
                href="/admin/orders"
                className="w-full border border-primary text-primary py-3 rounded-lg font-bold hover:bg-background transition-colors text-center"
              >
                Back to Orders
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
