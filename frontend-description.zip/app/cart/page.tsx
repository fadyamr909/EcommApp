"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import { useCart } from "@/hooks/use-cart"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Trash2, ArrowLeft, ShoppingCart, CheckCircle2 } from "lucide-react"

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, clearCart, cartTotal } = useCart()
  const [mounted, setMounted] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleRemove = (id: string) => {
    removeFromCart(id)
    setSuccessMessage("Item removed from cart")
    setTimeout(() => setSuccessMessage(""), 2000)
  }

  const handleCheckout = () => {
    setSuccessMessage("Processing order...")
    setTimeout(() => {
      clearCart()
      setSuccessMessage("Order placed successfully!")
    }, 1500)
  }

  const taxAmount = cartTotal * 0.1
  const totalWithTax = cartTotal + taxAmount

  if (!mounted) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading cart...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-4xl font-bold text-foreground">Shopping Cart</h1>
            {cart.length > 0 && (
              <span className="bg-primary text-primary-foreground px-4 py-2 rounded-full font-semibold">
                {cart.length} items
              </span>
            )}
          </div>

          {/* Success Message */}
          {successMessage && (
            <div className="mb-6 bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-3">
              <CheckCircle2 size={20} />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Empty State */}
          {cart.length === 0 ? (
            <div className="text-center py-12 bg-background rounded-lg">
              <div className="text-6xl mb-4">🛒</div>
              <p className="text-lg text-muted-foreground mb-6">Your cart is empty</p>
              <Link
                href="/store"
                className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors"
              >
                Continue Shopping
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-background border-b border-border">
                        <tr>
                          <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Product</th>
                          <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Price</th>
                          <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Quantity</th>
                          <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Subtotal</th>
                          <th className="px-6 py-3 text-center text-sm font-semibold text-foreground">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cart.map((item) => (
                          <tr key={item.id} className="border-b border-border hover:bg-background transition-colors">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                {item.image && (
                                  <div className="relative w-12 h-12 bg-background rounded">
                                    <Image
                                      src={item.image || "/placeholder.svg"}
                                      alt={item.name}
                                      fill
                                      className="object-cover rounded"
                                    />
                                  </div>
                                )}
                                <span className="font-semibold text-foreground">{item.name}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-foreground">${item.price.toFixed(2)}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  min="1"
                                  max="999"
                                  value={item.quantity}
                                  onChange={(e) =>
                                    updateQuantity(item.id, Math.max(1, Number.parseInt(e.target.value) || 1))
                                  }
                                  className="border border-border rounded px-2 py-1 w-16 text-center"
                                />
                              </div>
                            </td>
                            <td className="px-6 py-4 font-bold text-foreground">
                              ${(item.price * item.quantity).toFixed(2)}
                            </td>
                            <td className="px-6 py-4 text-center">
                              <button
                                onClick={() => handleRemove(item.id)}
                                className="text-destructive hover:text-destructive/80 transition-colors"
                                aria-label="Remove item"
                              >
                                <Trash2 size={18} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-card border-2 border-primary rounded-lg shadow-sm overflow-hidden">
                  <div className="bg-primary text-primary-foreground px-6 py-4 flex items-center gap-2">
                    <ShoppingCart size={20} />
                    <h2 className="text-lg font-bold">Order Summary</h2>
                  </div>

                  <div className="p-6 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Subtotal:</span>
                      <span className="font-semibold text-foreground">${cartTotal.toFixed(2)}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Tax (10%):</span>
                      <span className="font-semibold text-foreground">${taxAmount.toFixed(2)}</span>
                    </div>

                    <div className="border-t border-border pt-4 flex justify-between items-center">
                      <span className="font-bold text-lg text-foreground">Total:</span>
                      <span className="text-2xl font-bold text-primary">${totalWithTax.toFixed(2)}</span>
                    </div>

                    <div className="flex flex-col gap-3 pt-4">
                      <button
                        onClick={handleCheckout}
                        className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3 rounded-lg font-bold transition-colors"
                      >
                        Place Order
                      </button>
                      <Link
                        href="/store"
                        className="w-full border border-primary text-primary py-3 rounded-lg font-bold hover:bg-background transition-colors text-center flex items-center justify-center gap-2"
                      >
                        <ArrowLeft size={18} />
                        Continue Shopping
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}
