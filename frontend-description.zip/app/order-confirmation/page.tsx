"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import Link from "next/link"
import { CheckCircle2, ArrowLeft } from "lucide-react"

export default function OrderConfirmationPage() {
  const mockOrderId = "#ORD-001"
  const mockOrderDate = new Date().toLocaleString()
  const mockItems = [
    { id: "1", name: "Wireless Headphones", price: 79.99, quantity: 1 },
    { id: "3", name: "USB-C Cable", price: 14.99, quantity: 2 },
  ]
  const subtotal = 109.97
  const tax = 10.997
  const total = 120.967

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="bg-emerald-500 text-white px-6 py-12 text-center">
              <CheckCircle2 size={48} className="mx-auto mb-4" />
              <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
              <p className="text-lg opacity-90">Thank you for your order</p>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg">
                <p className="font-semibold">Your order has been placed successfully!</p>
                <p className="text-sm">
                  Order ID: <span className="font-bold">{mockOrderId}</span>
                </p>
                <p className="text-sm">
                  Order Date: <span className="font-bold">{mockOrderDate}</span>
                </p>
              </div>

              <div>
                <h2 className="font-bold text-foreground mb-3">Order Items</h2>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-background border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Product</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Price</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Quantity</th>
                        <th className="px-4 py-2 text-left text-sm font-semibold text-foreground">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockItems.map((item) => (
                        <tr key={item.id} className="border-b border-border">
                          <td className="px-4 py-3 text-foreground">{item.name}</td>
                          <td className="px-4 py-3 text-foreground">${item.price.toFixed(2)}</td>
                          <td className="px-4 py-3 text-foreground">{item.quantity}</td>
                          <td className="px-4 py-3 font-bold text-foreground">
                            ${(item.price * item.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="border-t border-border pt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-semibold text-foreground">${subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Tax (10%):</span>
                  <span className="font-semibold text-foreground">${tax.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center pt-3 border-t border-border">
                  <span className="font-bold text-lg text-foreground">Total:</span>
                  <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
                </div>
              </div>

              <Link
                href="/store"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-lg font-bold transition-colors text-center flex items-center justify-center gap-2"
              >
                <ArrowLeft size={20} />
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
