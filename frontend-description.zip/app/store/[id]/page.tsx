"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import type { Product } from "@/types/product"
import { useCart } from "@/hooks/use-cart"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ShoppingCart, ArrowLeft, CheckCircle2 } from "lucide-react"

// Mock data
const MOCK_PRODUCTS: Record<string, Product> = {
  "1": {
    id: "1",
    name: "Wireless Headphones",
    description:
      "High-quality sound with active noise cancellation. 30-hour battery life, comfortable fit for all-day wear.",
    price: 79.99,
    category: "Electronics",
    image: "/wireless-headphones.png",
  },
  "2": {
    id: "2",
    name: "Mechanical Keyboard",
    description:
      "RGB mechanical keyboard with premium mechanical switches. Fully programmable keys and ergonomic design.",
    price: 129.99,
    category: "Peripherals",
    image: "/mechanical-keyboard.png",
  },
}

interface ProductDetailsProps {
  params: Promise<{ id: string }>
}

export default function ProductDetailsPage({ params }: ProductDetailsProps) {
  const { addToCart } = useCart()
  const [product, setProduct] = useState<Product | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [successMessage, setSuccessMessage] = useState("")
  const [id, setId] = useState<string>("")

  useEffect(() => {
    params.then((p) => {
      setId(p.id)
      const prod = MOCK_PRODUCTS[p.id] || null
      setProduct(prod)
    })
  }, [params])

  const handleAddToCart = () => {
    if (!product) return
    addToCart(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
      },
      quantity,
    )
    setSuccessMessage("Added to cart!")
    setTimeout(() => setSuccessMessage(""), 3000)
  }

  if (!id) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  if (!product) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <Link href="/store" className="flex items-center gap-2 text-primary hover:underline mb-8">
              <ArrowLeft size={20} />
              Back to Store
            </Link>
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">Product not found</p>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <Link href="/store" className="flex items-center gap-2 text-primary hover:underline mb-8">
            <ArrowLeft size={20} />
            Back to Store
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column - Image */}
            <div className="bg-card border border-border rounded-lg shadow-sm p-6">
              <div className="relative w-full aspect-square bg-background rounded-lg overflow-hidden">
                {product.image ? (
                  <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground text-6xl">
                    📦
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Product Info */}
            <div className="bg-card border border-border rounded-lg shadow-sm p-6 flex flex-col">
              <div className="mb-6">
                <span className="bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                  {product.category}
                </span>
              </div>

              <h1 className="text-4xl font-bold text-card-foreground mb-4">{product.name}</h1>

              <p className="text-lg text-primary font-bold mb-6">${product.price.toFixed(2)}</p>

              <p className="text-card-foreground leading-relaxed mb-8">{product.description}</p>

              {/* Success Message */}
              {successMessage && (
                <div className="mb-6 bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-3">
                  <CheckCircle2 size={20} />
                  <span>{successMessage}</span>
                </div>
              )}

              {/* Add to Cart Form */}
              <div className="flex flex-col gap-4 mt-auto">
                <div className="flex items-center gap-4">
                  <label htmlFor="quantity" className="font-semibold text-card-foreground">
                    Quantity:
                  </label>
                  <input
                    id="quantity"
                    type="number"
                    min="1"
                    max="999"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
                    className="border border-border rounded-lg px-4 py-2 w-24 text-center"
                  />
                </div>

                <button
                  onClick={handleAddToCart}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <ShoppingCart size={20} />
                  Add to Cart
                </button>

                <Link
                  href="/store"
                  className="w-full border border-primary text-primary py-3 rounded-lg font-bold hover:bg-background transition-colors text-center flex items-center justify-center gap-2"
                >
                  <ArrowLeft size={20} />
                  Back to Store
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
