"use client"

import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import ProductCard from "@/components/product-card"
import type { Product } from "@/types/product"
import { useState, useEffect } from "react"
import { CheckCircle2 } from "lucide-react"

// Mock product data
const MOCK_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Wireless Headphones",
    description: "High-quality sound with noise cancellation",
    price: 79.99,
    category: "Electronics",
    image: "/wireless-headphones.png",
  },
  {
    id: "2",
    name: "Mechanical Keyboard",
    description: "RGB mechanical keyboard with premium switches",
    price: 129.99,
    category: "Peripherals",
    image: "/mechanical-keyboard.png",
  },
  {
    id: "3",
    name: "USB-C Cable",
    description: "Fast charging and data transfer",
    price: 14.99,
    category: "Accessories",
    image: "/usb-c-cable.jpg",
  },
  {
    id: "4",
    name: "Monitor Stand",
    description: "Adjustable monitor stand with storage",
    price: 49.99,
    category: "Furniture",
    image: "/monitor-stand.jpg",
  },
  {
    id: "5",
    name: "Webcam",
    description: "1080p HD webcam with auto-focus",
    price: 59.99,
    category: "Electronics",
    image: "/classic-webcam.png",
  },
  {
    id: "6",
    name: "Mouse Pad",
    description: "Large extended mouse pad with non-slip base",
    price: 24.99,
    category: "Accessories",
    image: "/simple-mouse-pad.png",
  },
]

export default function StorePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [successMessage, setSuccessMessage] = useState("")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setProducts(MOCK_PRODUCTS)
    setMounted(true)
  }, [])

  const handleAddToCart = () => {
    setSuccessMessage("Item added to cart!")
    setTimeout(() => setSuccessMessage(""), 3000)
  }

  if (!mounted) {
    return (
      <>
        <Header />
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">Loading products...</div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-4xl font-bold text-foreground">Our Products</h1>
            <span className="bg-primary text-primary-foreground px-4 py-2 rounded-full font-semibold">
              {products.length} items
            </span>
          </div>

          {/* Success Message */}
          {successMessage && (
            <div className="mb-6 bg-emerald-50 border border-emerald-500 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-3">
              <CheckCircle2 size={20} />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Empty State */}
          {products.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📭</div>
              <p className="text-lg text-muted-foreground">No products available</p>
            </div>
          )}

          {/* Product Grid */}
          {products.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} onAddToCart={handleAddToCart} />
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}
