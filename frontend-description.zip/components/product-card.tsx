"use client"

import Link from "next/link"
import Image from "next/image"
import { ShoppingCart, Eye } from "lucide-react"
import type { Product } from "@/types/product"
import { useCart } from "@/hooks/use-cart"
import { useState } from "react"

interface ProductCardProps {
  product: Product
  onAddToCart?: () => void
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const { addToCart } = useCart()
  const [justAdded, setJustAdded] = useState(false)

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    })
    setJustAdded(true)
    setTimeout(() => setJustAdded(false), 2000)
    onAddToCart?.()
  }

  return (
    <div className="bg-card border border-border rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden flex flex-col h-full">
      {/* Product Image */}
      <div className="relative w-full h-48 bg-background overflow-hidden">
        {product.image ? (
          <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <span className="text-4xl">📦</span>
          </div>
        )}
        {/* Category Badge */}
        <div className="absolute top-3 right-3 bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
          {product.category}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-bold text-card-foreground mb-2 line-clamp-2">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">{product.description}</p>
        <p className="text-xl font-bold text-primary mb-4">${product.price.toFixed(2)}</p>

        {/* Actions */}
        <div className="flex flex-col gap-2">
          <button
            onClick={handleAddToCart}
            className={`w-full py-2 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2 ${
              justAdded ? "bg-emerald-500 text-white" : "bg-emerald-500 hover:bg-emerald-600 text-white"
            }`}
          >
            <ShoppingCart size={18} />
            {justAdded ? "Added to Cart!" : "Add to Cart"}
          </button>
          <Link
            href={`/store/${product.id}`}
            className="w-full py-2 border border-primary text-primary rounded-lg font-semibold hover:bg-background transition-colors flex items-center justify-center gap-2"
          >
            <Eye size={18} />
            View Details
          </Link>
        </div>
      </div>
    </div>
  )
}
