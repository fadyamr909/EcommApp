"use client"

import Link from "next/link"
import { useState } from "react"
import { ShoppingCart, Menu, X, Settings, Grid3x3 } from "lucide-react"
import CartBadge from "./cart-badge"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-white shadow-sm">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Brand */}
          <Link href="/" className="flex items-center gap-2 text-2xl font-bold text-primary hover:text-primary/80">
            <Grid3x3 size={28} />
            <span>EcommerceApp</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/store" className="flex items-center gap-2 text-foreground hover:text-primary">
              <Grid3x3 size={20} />
              <span>Store</span>
            </Link>
            <Link href="/cart" className="flex items-center gap-2 text-foreground hover:text-primary relative">
              <ShoppingCart size={20} />
              <span>Cart</span>
              <CartBadge />
            </Link>
            <div className="relative group">
              <button className="flex items-center gap-2 text-foreground hover:text-primary">
                <Settings size={20} />
                <span>Admin</span>
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-white border border-border rounded-lg shadow-lg hidden group-hover:block">
                <Link href="/admin/products" className="block px-4 py-2 hover:bg-background text-foreground">
                  Products
                </Link>
                <Link
                  href="/admin/orders"
                  className="block px-4 py-2 hover:bg-background text-foreground border-t border-border"
                >
                  Orders
                </Link>
              </div>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 flex flex-col gap-4 border-t border-border pt-4">
            <Link href="/store" className="flex items-center gap-2 text-foreground hover:text-primary">
              <Grid3x3 size={20} />
              <span>Store</span>
            </Link>
            <Link href="/cart" className="flex items-center gap-2 text-foreground hover:text-primary">
              <ShoppingCart size={20} />
              <span>Cart</span>
            </Link>
            <Link href="/admin/products" className="flex items-center gap-2 text-foreground hover:text-primary">
              <Settings size={20} />
              <span>Admin - Products</span>
            </Link>
            <Link href="/admin/orders" className="flex items-center gap-2 text-foreground hover:text-primary">
              <Settings size={20} />
              <span>Admin - Orders</span>
            </Link>
          </div>
        )}
      </nav>
    </header>
  )
}
