"use client"

import { useCart } from "@/hooks/use-cart"

export default function CartBadge() {
  const { cartCount } = useCart()

  if (cartCount === 0) return null

  return (
    <span className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
      {cartCount}
    </span>
  )
}
