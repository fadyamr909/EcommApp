import type { CartItem } from "@/hooks/use-cart"

export interface Order {
  id: string
  date: string
  items: CartItem[]
  subtotal: number
  tax: number
  total: number
}
